# -*- encoding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 5
_modified_time = 1280164186.3951709
_template_filename='/home/rhh/Downloads/demo/demo/templates/search/payload.mako'
_template_uri='/search/payload.mako'
_template_cache=cache.Cache(__name__, _modified_time)
_source_encoding='utf-8'
from webhelpers.html import escape
_exports = []


def render_body(context,**pageargs):
    context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        h = context.get('h', UNDEFINED)
        c = context.get('c', UNDEFINED)
        __M_writer = context.writer()
        # SOURCE LINE 1
        __M_writer(escape(c.matches.get_matches_estimated()))
        __M_writer(u' result(s)\n\n')
        # SOURCE LINE 3
        for match in c.matches:
            # SOURCE LINE 4
            __M_writer(u'<br>\n<p>\n')
            # SOURCE LINE 6
            __M_writer(escape(h.literal(match.document.get_data().replace('\n', '<br>'))))
            __M_writer(u'\n</p>\n<br>\n')
            pass
        return ''
    finally:
        context.caller_stack._pop_frame()


