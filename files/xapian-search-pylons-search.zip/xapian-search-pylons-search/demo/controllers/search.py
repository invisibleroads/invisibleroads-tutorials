# Import pylons modules
from pylons import request, response, session, tmpl_context as c, config
from pylons.controllers.util import abort, redirect_to
# Import system modules
import logging; log = logging.getLogger(__name__)
import xapian
import os
# Import custom modules
from demo.lib.base import BaseController, render


class SearchController(BaseController):

    def index(self):
        return render('/search/index.mako')

    def query(self):
        # Load queryString
        queryString = request.GET.get('q', '').strip()
        # If queryString exists,
        if queryString:
            # Connect to database
            try:
                database = xapian.Database(config['path_indices'])
            except xapian.DatabaseOpeningError:
                return 'Cannot open database at ' + config['path_indices']
            # Parse query string
            queryParser = xapian.QueryParser()
            queryParser.set_stemmer(xapian.Stem('english'))
            queryParser.set_database(database)
            queryParser.set_stemming_strategy(xapian.QueryParser.STEM_SOME)
            query = queryParser.parse_query(queryString)
            # Set offset and limit for pagination
            offset, limit = 0, database.get_doccount()
            # Start query session
            enquire = xapian.Enquire(database)
            enquire.set_query(query)
            # Display matches
            c.matches = enquire.get_mset(offset, limit)
            # Render
            return render('/search/payload.mako')
