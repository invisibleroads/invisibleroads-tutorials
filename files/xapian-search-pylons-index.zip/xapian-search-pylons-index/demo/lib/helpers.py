"""Helper functions

Consists of functions to typically be used within templates, but also
available to Controllers. This module is available to templates as 'h'.
"""
# Import pylons modules
from webhelpers.html.tags import *
from webhelpers.html import literal
from webhelpers.util import html_escape
from routes import url_for
