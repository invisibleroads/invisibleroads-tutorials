# Import pylons modules
from pylons import request, response, session, tmpl_context as c
from pylons.controllers.util import abort, redirect_to
# Import system modules
import logging; log = logging.getLogger(__name__)
# Import custom modules
from demo.lib.base import BaseController, render


class SearchController(BaseController):

    def index(self):
        # Render template
        return render('/search/index.mako')
