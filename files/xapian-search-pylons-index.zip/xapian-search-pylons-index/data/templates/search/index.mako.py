# -*- encoding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 5
_modified_time = 1280163862.5156391
_template_filename='/home/rhh/Downloads/demo/demo/templates/search/index.mako'
_template_uri='/search/index.mako'
_template_cache=cache.Cache(__name__, _modified_time)
_source_encoding='utf-8'
from webhelpers.html import escape
_exports = []


def render_body(context,**pageargs):
    context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        h = context.get('h', UNDEFINED)
        __M_writer = context.writer()
        # SOURCE LINE 1
        __M_writer(u'<html>\n<head>\n    ')
        # SOURCE LINE 3
        __M_writer(escape(h.javascript_link('/files/jquery-1.4.2.min.js')))
        __M_writer(u'\n    <script>\n        $(document).ready(function() {\n        });\n    </script>\n</head>\n<body>\n    <input id=query>\n    <input id=button_search type=button value=Search>\n</body>\n</html>\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


